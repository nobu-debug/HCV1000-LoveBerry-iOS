/*
    Copyright 2023 Jesse Talavera-Greenberg

    melonDS DS is free software: you can redistribute it and/or modify it under
    the terms of the GNU General Public License as published by the Free
    Software Foundation, either version 3 of the License, or (at your option)
    any later version.

    melonDS DS is distributed in the hope that it will be useful, but WITHOUT ANY
    WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
    FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with melonDS DS. If not, see http://www.gnu.org/licenses/.
*/

#include "software.hpp"

#include <cmath>

#include <retro_assert.h>

#include <NDS.h>
#include <gfx/scaler/pixconv.h>

#include "config/config.hpp"
#include "config/types.hpp"
#include "input/input.hpp"
#include "message/error.hpp"
#include "screenlayout.hpp"
#include "tracy.hpp"

using glm::ivec2;
using glm::mat3;
using glm::vec2;
using glm::vec3;
using glm::uvec2;
using std::span;

MelonDsDs::SoftwareRenderState::SoftwareRenderState(const CoreConfig& config) noexcept :
    buffer(1, 1),
    hybridBuffer(1, 1),
    hybridScaler(
        SCALER_FMT_ARGB8888,
        SCALER_FMT_ARGB8888,
        config.ScreenFilter() == ScreenFilter::Nearest ? SCALER_TYPE_POINT : SCALER_TYPE_BILINEAR,
        NDS_SCREEN_WIDTH,
        NDS_SCREEN_HEIGHT,
        NDS_SCREEN_WIDTH * config.HybridRatio(),
        NDS_SCREEN_HEIGHT * config.HybridRatio()
    ),
    secondaryScaleBuffer(1, 1),
    secondaryScaleScaler(
        SCALER_FMT_ARGB8888, SCALER_FMT_ARGB8888,
        config.SecondaryScreenFilter() == ScreenFilter::Nearest ? SCALER_TYPE_POINT : SCALER_TYPE_BILINEAR,
        NDS_SCREEN_WIDTH,
        NDS_SCREEN_HEIGHT,
        NDS_SCREEN_WIDTH,
        NDS_SCREEN_HEIGHT
    ) {
}

// TODO: Consider using RETRO_ENVIRONMENT_GET_CURRENT_SOFTWARE_FRAMEBUFFER
void MelonDsDs::SoftwareRenderState::Render(
    melonDS::NDS& nds,
    const InputState& inputState,
    const CoreConfig& config,
    const ScreenLayoutData& screenLayout
) noexcept {
    ZoneScopedN(TracyFunction);

    buffer.SetSize(screenLayout.BufferSize());

    if (IsHybridLayout(screenLayout.Layout()) || IsLargeScreenLayout(screenLayout.Layout())) {
        uvec2 requiredHybridBufferSize = NDS_SCREEN_SIZE<unsigned> * screenLayout.HybridRatio();
        hybridBuffer.SetSize(requiredHybridBufferSize);

        auto filter = config.ScreenFilter() == ScreenFilter::Nearest ? SCALER_TYPE_POINT : SCALER_TYPE_BILINEAR;
        hybridScaler.SetScalerType(filter);
        hybridScaler.SetOutSize(requiredHybridBufferSize.x, requiredHybridBufferSize.y);
    }

    if (LayoutSupportsSecondaryScreenScale(screenLayout.Layout()) && screenLayout.SecondaryScreenScale() < 100) {
        float f = screenLayout.SecondaryScreenScaleFactor();
        unsigned scaledW = static_cast<unsigned>(NDS_SCREEN_WIDTH * f);
        unsigned scaledH = static_cast<unsigned>(NDS_SCREEN_HEIGHT * f);
        secondaryScaleBuffer.SetSize({ scaledW, scaledH });
        auto filter = config.SecondaryScreenFilter() == ScreenFilter::Nearest ? SCALER_TYPE_POINT : SCALER_TYPE_BILINEAR;
        secondaryScaleScaler.SetScalerType(filter);
        secondaryScaleScaler.SetOutSize(scaledW, scaledH);
    }

    const uint32_t* topScreenBuffer = nds.GPU.Framebuffer[nds.GPU.FrontBuffer][0].get();
    const uint32_t* bottomScreenBuffer = nds.GPU.Framebuffer[nds.GPU.FrontBuffer][1].get();
    CombineScreens(
        span<const uint32_t, NDS_SCREEN_AREA<size_t>>(topScreenBuffer, NDS_SCREEN_AREA<size_t>),
        span<const uint32_t, NDS_SCREEN_AREA<size_t>>(bottomScreenBuffer, NDS_SCREEN_AREA<size_t>),
        screenLayout
    );

    if (!nds.IsLidClosed() && inputState.CursorVisible()) {
        DrawCursor(inputState, config, screenLayout);
    }

    retro::video_refresh(buffer[0], buffer.Width(), buffer.Height(), buffer.Stride());

#ifdef HAVE_TRACY
    if (tracy::ProfilerAvailable()) {
        // If Tracy is connected...
        ZoneScopedN("MelonDsDs::render::RenderSoftware::SendFrameToTracy");
        std::unique_ptr<uint8_t[]> frame = std::make_unique<uint8_t[]>(buffer.Width() * buffer.Height() * 4);
        {
            ZoneScopedN("conv_argb8888_abgr8888");
            conv_argb8888_abgr8888(frame.get(), buffer[0], buffer.Width(), buffer.Height(), buffer.Stride(), buffer.Stride());
        }
        // libretro wants pixels in XRGB8888 format,
        // but Tracy wants them in XBGR8888 format.

        FrameImage(frame.get(), buffer.Width(), buffer.Height(), 0, false);
    }
#endif
}

void MelonDsDs::SoftwareRenderState::Render(
    const error::ErrorScreen& error,
    const ScreenLayoutData& screenLayout
) noexcept {
    ZoneScopedN(TracyFunction);

    buffer.SetSize(screenLayout.BufferSize());
    CombineScreens(error.TopScreen(), error.BottomScreen(), screenLayout);

    retro::video_refresh(buffer[0], buffer.Width(), buffer.Height(), buffer.Stride());
}

void MelonDsDs::SoftwareRenderState::CopyScreen(const uint32_t* src, uvec2 destTranslation, ScreenLayout layout) noexcept {
    ZoneScopedN(TracyFunction);
    // Only used for software rendering

    // melonDS's software renderer draws each emulated screen to its own buffer,
    // and then the frontend combines them based on the current layout.
    // In the original buffer, all pixels are contiguous in memory.
    // If a screen doesn't need anything drawn to its side (such as blank space or another screen),
    // then we can just copy the entire screen at once.
    // But if a screen *does* need anything drawn on either side of it,
    // then its pixels can't all be contiguous in memory.
    // In that case, we have to copy each row of pixels individually to a different offset.
    if (LayoutSupportsDirectCopy(layout)) {
        buffer.CopyDirect(src, destTranslation);
    }
    else {
        // Not all of this screen's pixels will be contiguous in memory, so we have to copy them row by row
        buffer.CopyRows(src, destTranslation, NDS_SCREEN_SIZE<unsigned>);
    }
}

void MelonDsDs::SoftwareRenderState::DrawCursor(const InputState& input, const CoreConfig& config,
    const ScreenLayoutData& screenLayout
) noexcept {
    ZoneScopedN(TracyFunction);
    // Only used for software rendering

    if (screenLayout.Layout() == ScreenLayout::TopOnly)
        return;

    float cursorRadius = config.CursorSize();
    if (screenLayout.Layout() == ScreenLayout::LargescreenBottom || screenLayout.Layout() == ScreenLayout::FlippedLargescreenBottom) {
        cursorRadius *= static_cast<float>(screenLayout.HybridRatio());
    }

    ScreenLayout layout = screenLayout.Layout();
    ivec2 touch = clamp(input.ConsoleTouchPosition(), ivec2(0), ivec2(NDS_SCREEN_WIDTH - 1, NDS_SCREEN_HEIGHT - 1));

    bool secondaryTouchInBounds =
        (input.TouchPosition().x >= 0 && input.TouchPosition().x < NDS_SCREEN_WIDTH) &&
        (input.TouchPosition().y >= 0 && input.TouchPosition().y < NDS_SCREEN_HEIGHT);
    bool touchUsesHybrid =
        (layout == ScreenLayout::HybridBottom || layout == ScreenLayout::FlippedHybridBottom) &&
        (screenLayout.HybridSmallScreenLayout() == HybridSideScreenDisplay::One || !secondaryTouchInBounds);

    const mat3& touchScreenMatrix = touchUsesHybrid ? screenLayout.GetHybridScreenMatrix() : screenLayout.GetBottomScreenMatrix();
    vec3 p0 = touchScreenMatrix * vec3(vec2(touch) - vec2(cursorRadius), 1.0f);
    vec3 p1 = touchScreenMatrix * vec3(vec2(touch) + vec2(cursorRadius), 1.0f);
    float x0 = std::min(p0.x, p1.x);
    float y0 = std::min(p0.y, p1.y);
    float x1 = std::max(p0.x, p1.x);
    float y1 = std::max(p0.y, p1.y);
    ivec2 startI = clamp(ivec2(static_cast<int>(std::floor(x0)), static_cast<int>(std::floor(y0))), ivec2(0), ivec2(buffer.Size()));
    ivec2 endI = clamp(ivec2(static_cast<int>(std::ceil(x1)), static_cast<int>(std::ceil(y1))), ivec2(0), ivec2(buffer.Size()));
    uvec2 start = uvec2(startI);
    uvec2 end = uvec2(endI);
    for (uint32_t y = start.y; y < end.y; y++) {
        for (uint32_t x = start.x; x < end.x; x++) {
            // TODO: Replace with SIMD (does GLM have a SIMD version of this?)
            uint32_t& pixel = buffer[uvec2(x, y)];
            pixel = (0xFFFFFF - pixel) | 0xFF000000;
        }
    }
}

void MelonDsDs::SoftwareRenderState::CombineScreens(
    std::span<const uint32_t, NDS_SCREEN_AREA<size_t>> topBuffer,
    std::span<const uint32_t, NDS_SCREEN_AREA<size_t>> bottomBuffer,
    const ScreenLayoutData& screenLayout
) noexcept {
    ZoneScopedN(TracyFunction);

    buffer.Clear();
    ScreenLayout layout = screenLayout.Layout();

    if (IsHybridLayout(layout)) {
        auto primaryBuffer = layout == ScreenLayout::HybridTop || layout == ScreenLayout::FlippedHybridTop ? topBuffer : bottomBuffer;

        hybridScaler.Scale(hybridBuffer[0], primaryBuffer.data());
        buffer.CopyRows(
            hybridBuffer[0],
            screenLayout.GetHybridScreenTranslation(),
            NDS_SCREEN_SIZE<unsigned> * screenLayout.HybridRatio()
        );

        HybridSideScreenDisplay smallScreenLayout = screenLayout.HybridSmallScreenLayout();

        if (smallScreenLayout == HybridSideScreenDisplay::Both || layout == ScreenLayout::HybridBottom || layout == ScreenLayout::FlippedHybridBottom) {
            // If we should display both screens, or if the bottom one is the primary...
            buffer.CopyRows(topBuffer.data(), screenLayout.GetTopScreenTranslation(), NDS_SCREEN_SIZE<unsigned>);
        }

        if (smallScreenLayout == HybridSideScreenDisplay::Both || layout == ScreenLayout::HybridTop || layout == ScreenLayout::FlippedHybridTop) {
            // If we should display both screens, or if the top one is being focused...
            buffer.CopyRows(bottomBuffer.data(), screenLayout.GetBottomScreenTranslation(), NDS_SCREEN_SIZE<unsigned>);
        }
    } 
    else if (IsLargeScreenLayout(layout)) {
        bool focusTop = layout == ScreenLayout::LargescreenTop || layout == ScreenLayout::FlippedLargescreenTop;
        if (focusTop) {
            auto primaryBuffer = topBuffer;
            hybridScaler.Scale(hybridBuffer[0], primaryBuffer.data());
            buffer.CopyRows(
                hybridBuffer[0],
                screenLayout.GetTopScreenTranslation(),
                NDS_SCREEN_SIZE<unsigned> * screenLayout.HybridRatio()
            );
            // If the top screen is the primary copy the bottom to the small screen
            CopyScreen(bottomBuffer.data(), screenLayout.GetBottomScreenTranslation(), layout);
        } else {
            auto primaryBuffer = bottomBuffer;
            hybridScaler.Scale(hybridBuffer[0], primaryBuffer.data());
            buffer.CopyRows(
                hybridBuffer[0],
                screenLayout.GetBottomScreenTranslation(),
                NDS_SCREEN_SIZE<unsigned> * screenLayout.HybridRatio()
            );            
            // If the bottom screen is the primary copy the top to the small screen
            CopyScreen(topBuffer.data(), screenLayout.GetTopScreenTranslation(), layout);
        }
    } 
    else {
        if (layout != ScreenLayout::BottomOnly) {
            if (layout == ScreenLayout::BottomTop && LayoutSupportsSecondaryScreenScale(layout) && screenLayout.SecondaryScreenScale() < 100) {
                secondaryScaleScaler.Scale(secondaryScaleBuffer[0], topBuffer.data());
                buffer.CopyRows(secondaryScaleBuffer[0], screenLayout.GetTopScreenTranslation(), secondaryScaleBuffer.Size());
            } else {
                CopyScreen(topBuffer.data(), screenLayout.GetTopScreenTranslation(), layout);
            }
        }

        if (layout != ScreenLayout::TopOnly) {
            if (layout != ScreenLayout::BottomTop && LayoutSupportsSecondaryScreenScale(layout) && screenLayout.SecondaryScreenScale() < 100) {
                secondaryScaleScaler.Scale(secondaryScaleBuffer[0], bottomBuffer.data());
                buffer.CopyRows(secondaryScaleBuffer[0], screenLayout.GetBottomScreenTranslation(), secondaryScaleBuffer.Size());
            } else {
                CopyScreen(bottomBuffer.data(), screenLayout.GetBottomScreenTranslation(), layout);
            }
        }
    }
}

