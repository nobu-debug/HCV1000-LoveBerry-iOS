HCV-1000 / Love and Berry build package

Base: melonDS DS 1.3.1
Pinned upstream melonDS dependency: 7117178c2dd56df32b6534ba6a54ad1f8547e693

The CMake configuration fetches the exact pinned melonDS dependency and applies
patches/melonds-7117178-hcv1000-loveberry.patch before configuring it.

Target behavior:
- Detect NDS game code ALBJ (Oshare Majo Love and Berry: DS Collection).
- Automatically insert a virtual Sega HCV-1000 in Slot-2.
- HCV-1000 detection behavior from the published hardware research.
- HCV_CNT: 0x0A000000.
- HCV_DATA: 0x0A000010..0x0A00001F.
- EXMEMCNT: 0xE877.
- Test barcode: *OUMLMHQ697D*, padded with 0x5F.
- No Love and Berry ROM is included.

Important:
This package is source/build material, not an IPA. It is not Apple-signed and
has not been tested on an iPhone in this environment.
